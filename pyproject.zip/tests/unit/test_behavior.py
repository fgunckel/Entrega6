"""Behavior tests for the ADA validation/repair cycle.

All tests use fake chat models and fake encoders: no network, no Groq key,
no Hugging Face downloads. They verify graph outcomes and transitions,
not just function existence.
"""

import numpy as np
import pytest

from ada.agents.analyst import derive_scores_from_evidence
from ada.graph import compile_graph, route_after_validator
from ada.schemas import AlternativeAnalysis, Criterion, CriterionScore
from ada.tools.scoring import calculate_weighted_score, rank_alternatives

# ---------------------------------------------------------------------------
# Fakes
# ---------------------------------------------------------------------------


class FakeChatModel:
    """Routes deterministically from the supervisor context text."""

    def invoke(self, messages):
        text = str(messages[-1][1] if isinstance(messages[-1], tuple) else messages[-1])
        if "Research artifact present: False" in text:
            nxt = "researcher"
        elif "Analysis artifact present: False" in text:
            nxt = "analyst"
        elif "Validation result: none" in text:
            nxt = "validator"
        elif "is_valid=True" in text:
            nxt = "synthesizer"
        else:
            nxt = "limited_finish"

        class Response:
            content = (
                f'{{"next_agent": "{nxt}", "reason": "fake routing", '
                f'"task_completed": false}}'
            )

        return Response()


class BrokenChatModel:
    def invoke(self, messages):
        raise ConnectionError("network down")


class GarbageChatModel:
    def invoke(self, messages):
        class Response:
            content = "not a json object at all"

        return Response()


@pytest.fixture
def documents():
    from ada.retrieval.documents import TechnicalDocument

    return [
        TechnicalDocument(
            document_id="doc-1",
            title="Monolito modular",
            content=(
                "Un monolito modular organiza el código en módulos "
                "con límites claros dentro de una aplicación."
            ),
            source="https://example.com/modular-monolith",
            topic="arquitectura",
        ),
        TechnicalDocument(
            document_id="doc-2",
            title="Microservicios",
            content=(
                "Los microservicios separan capacidades de negocio "
                "en servicios independientes."
            ),
            source="https://microservices.io/patterns/microservices.html",
            topic="arquitectura",
        ),
    ]


def fake_encoder(texts: list[str]) -> "np.ndarray":
    vectors = []
    for text in texts:
        normalized = text.lower()
        if "monolito" in normalized:
            vectors.append([0.0, 1.0])
        else:
            vectors.append([1.0, 0.0])
    return np.asarray(vectors, dtype=np.float32)


def initial_state() -> dict:
    return {
        "user_request": (
            "Decidir arquitectura para una API .NET. Equipo pequeño, "
            "presión por entregar rápido, no se requieren despliegues "
            "independientes."
        ),
        "system_profile": {},
        "criteria": [],
        "next_agent": "researcher",
        "routing_reason": "inicio",
        "steps": 0,
        "retries": 0,
        "task_completed": False,
    }


# ---------------------------------------------------------------------------
# 1. Flujo exitoso
# ---------------------------------------------------------------------------


def test_successful_flow_produces_final_report(documents):
    graph = compile_graph(FakeChatModel(), encoder=fake_encoder, documents=documents)
    result = graph.invoke(initial_state())

    visited = [c["agent"] for c in result.get("contributions", [])]
    assert "researcher" in visited
    assert "analyst" in visited
    assert "validator" in visited
    assert "synthesizer" in visited
    assert result["final_report"]["status"] == "complete"
    assert result["validation_result"]["is_valid"] is True


# ---------------------------------------------------------------------------
# 2. Delegación dinámica del Supervisor
# ---------------------------------------------------------------------------


def test_supervisor_delegates_dynamically_by_state(documents):
    graph = compile_graph(FakeChatModel(), encoder=fake_encoder, documents=documents)
    result = graph.invoke(initial_state())

    contributions = result.get("contributions", [])
    # The supervisor must delegate in order: research first, then analysis.
    researcher_steps = [c["step"] for c in contributions if c["agent"] == "researcher"]
    analyst_steps = [c["step"] for c in contributions if c["agent"] == "analyst"]
    assert researcher_steps and analyst_steps
    assert min(researcher_steps) < min(analyst_steps)


# ---------------------------------------------------------------------------
# 3. Routing determinístico post-Validator
# ---------------------------------------------------------------------------


def test_route_after_validator_is_deterministic():
    assert (
        route_after_validator({"validation_result": {"is_valid": True}})
        == "synthesizer"
    )
    assert (
        route_after_validator(
            {
                "validation_result": {
                    "is_valid": False,
                    "research_errors": ["no evidence"],
                    "analysis_errors": [],
                },
                "retries": 0,
            }
        )
        == "researcher"
    )
    assert (
        route_after_validator(
            {
                "validation_result": {
                    "is_valid": False,
                    "research_errors": [],
                    "analysis_errors": ["score mismatch"],
                },
                "retries": 0,
            }
        )
        == "analyst"
    )
    assert (
        route_after_validator(
            {
                "validation_result": {
                    "is_valid": False,
                    "research_errors": [],
                    "analysis_errors": ["x"],
                },
                "retries": 99,
            }
        )
        == "limited_finish"
    )


# ---------------------------------------------------------------------------
# 4. Reintento del Researcher: contador aumenta y segunda validación aprueba
# ---------------------------------------------------------------------------


def test_researcher_receives_errors_and_retries(documents):
    from ada.graph import make_researcher_node

    state = {
        "user_request": "test",
        "retries": 1,
        "steps": 2,
        "validation_errors": ["Research artifact contains no evidence."],
        "contributions": [],
    }

    update = make_researcher_node(encoder=fake_encoder, documents=documents)(state)

    # The researcher cleared the pending errors and recorded the attempt.
    assert update["validation_errors"] == []
    contribution = update["contributions"][-1]
    assert "Reintento tras validación" in update["contributions"][-1]["summary"]
    assert contribution["attempt"] == 1
    assert contribution["errors"] == ["Research artifact contains no evidence."]
    # The artifact was regenerated (new version replaces the invalid one).
    assert update["research_artifact"] is not None


# ---------------------------------------------------------------------------
# 5. Reintento del Analyst: mismo comportamiento
# ---------------------------------------------------------------------------


def test_analyst_receives_errors_and_retries(documents):
    from ada.graph import analyst_node

    criteria = [Criterion.model_validate(item) for item in [
        {"criterion_id": "c1", "name": "C1", "weight": 1.0, "description": "d"}
    ]]
    research = {
        "query": "q",
        "evidence": [
            {
                "document_id": "doc-1",
                "chunk_id": "doc-1#full",
                "title": "Monolito modular",
                "excerpt": "Un monolito modular organiza módulos.",
                "relevance_score": 0.5,
                "retrieval_method": ["bm25"],
                "content_hash": "abc123",
            }
        ],
        "covered_topics": [],
        "evidence_gaps": [],
        "confidence_score": 0.5,
    }
    state = {
        "user_request": "test",
        "system_profile": {},
        "criteria": [criterion.model_dump() for criterion in criteria],
        "research_artifact": research,
        "retries": 1,
        "steps": 3,
        "validation_errors": ["Weighted score mismatch for 'a'."],
        "contributions": [],
    }

    update = analyst_node(state)

    assert update["validation_errors"] == []
    assert update["analysis_artifact"] is not None
    assert "Reintento tras validación" in update["contributions"][-1]["summary"]
    assert update["contributions"][-1]["attempt"] == 1


# ---------------------------------------------------------------------------
# 5b. Ciclo de reparación end-to-end: Validator devuelve al responsable
# ---------------------------------------------------------------------------


def test_repair_round_returns_to_responsible_specialist(documents):
    from ada.graph import validator_node

    # An analysis citing an unknown evidence ID must be classified as an
    # analysis error and routed back to the analyst.
    state = {
        "user_request": "test",
        "criteria": [],
        "retries": 0,
        "steps": 3,
        "research_artifact": {
            "query": "q",
            "evidence": [
                {
                    "document_id": "doc-1",
                    "chunk_id": "doc-1#full",
                    "title": "T",
                    "excerpt": "E",
                    "relevance_score": 0.5,
                    "retrieval_method": ["bm25"],
                    "content_hash": "abc123",
                }
            ],
            "covered_topics": [],
            "evidence_gaps": [],
            "confidence_score": 0.5,
        },
        "analysis_artifact": {
            "alternatives": [
                {
                    "alternative_id": "a",
                    "name": "A",
                    "scores": [
                        {
                            "criterion_id": "c1",
                            "weight": 1.0,
                            "score": 4,
                            "rationale": "r",
                            "evidence_ids": ["doc-999"],
                        }
                    ],
                    "weighted_score": 0.8,
                },
                {
                    "alternative_id": "b",
                    "name": "B",
                    "scores": [
                        {
                            "criterion_id": "c1",
                            "weight": 1.0,
                            "score": 3,
                            "rationale": "r",
                        }
                    ],
                    "weighted_score": 0.8,
                },
            ],
            "ranking": ["a", "b"],
            "data_gaps": [],
            "qualitative_summary": "s",
        },
    }

    result = validator_node(state)
    validation = result["validation_result"]

    assert validation["is_valid"] is False
    assert validation["analysis_errors"]
    assert not validation["research_errors"]
    # Deterministic repair routing: analyst receives the specific errors.
    assert route_after_validator(result) == "analyst"
    assert result["retries"] == 1
    assert result["validation_errors"] == validation["analysis_errors"]


# ---------------------------------------------------------------------------
# 6. Reintentos agotados: finaliza sin bucle y marca revisión humana
# ---------------------------------------------------------------------------


def test_exhausted_retries_finish_safely_without_loop(documents):
    graph = compile_graph(FakeChatModel(), encoder=fake_encoder, documents=documents)

    state = initial_state()
    state["retries"] = 2  # ADA_MAX_RETRIES default is 2
    result = graph.invoke(state)

    # With valid artifacts the flow still completes normally (retries only
    # gate repair rounds, not success), but the counter stays bounded.
    assert result["final_report"]["status"] == "complete"
    assert result["retries"] <= 3  # bounded, no runaway increments


def test_exhausted_retries_route_to_limited_finish():
    # With retries exhausted, the deterministic router must stop the
    # repair cycle instead of looping back to a specialist.
    state = {
        "validation_result": {
            "is_valid": False,
            "research_errors": [],
            "analysis_errors": ["score mismatch"],
        },
        "retries": 2,
    }
    assert route_after_validator(state) == "limited_finish"


# ---------------------------------------------------------------------------
# 7. No hay síntesis exitosa si la validación falla
# ---------------------------------------------------------------------------


def test_synthesizer_never_publishes_success_on_failed_validation():
    from ada.graph import synthesizer_node

    state = {
        "user_request": "test",
        "validation_result": {
            "is_valid": False,
            "errors": ["Weighted score mismatch for 'a'."],
            "warnings": [],
            "requires_human_review": False,
        },
        "research_artifact": {"evidence": []},
        "analysis_artifact": {"alternatives": [], "ranking": []},
    }

    report = synthesizer_node(state)["final_report"]
    assert report["status"] == "needs_human_review"
    assert report["recommendation"] != "complete"


# ---------------------------------------------------------------------------
# 8. No hay finalización exitosa cuando faltan artefactos obligatorios
# ---------------------------------------------------------------------------


def test_validator_fails_when_required_artifacts_missing():
    from ada.graph import validator_node

    result = validator_node({"criteria": [], "retries": 0, "steps": 1})
    validation = result["validation_result"]

    assert validation["is_valid"] is False
    assert any("Missing research artifact" in error for error in validation["errors"])
    assert any("Missing analysis artifact" in error for error in validation["errors"])
    # Deterministic routing must not go to the synthesizer.
    assert route_after_validator(result) in {"researcher", "limited_finish"}


# ---------------------------------------------------------------------------
# 9. El scoring es determinístico y no depende del LLM
# ---------------------------------------------------------------------------


def test_scoring_is_deterministic_and_llm_independent():
    criteria = [Criterion.model_validate(item) for item in [
        {"criterion_id": "c1", "name": "C1", "weight": 0.6, "description": "d"},
        {"criterion_id": "c2", "name": "C2", "weight": 0.4, "description": "d"},
    ]]
    scores = [
        CriterionScore.model_validate(item)
        for item in [
            {"criterion_id": "c1", "weight": 0.6, "score": 4, "rationale": "r"},
            {"criterion_id": "c2", "weight": 0.4, "score": 2, "rationale": "r"},
        ]
    ]

    first = calculate_weighted_score(scores, criteria)
    second = calculate_weighted_score(scores, criteria)
    assert first == pytest.approx(second)

    # The ranking is derived deterministically from the weighted scores.
    analyses = [
        AlternativeAnalysis.model_validate(item)
        for item in [
            {
                "alternative_id": "a",
                "name": "A",
                "scores": [
                    {"criterion_id": "c1", "weight": 0.6, "score": 4, "rationale": "r"},
                    {"criterion_id": "c2", "weight": 0.4, "score": 4, "rationale": "r"},
                ],
                "weighted_score": 0.8,
            },
            {
                "alternative_id": "b",
                "name": "B",
                "scores": [
                    {"criterion_id": "c1", "weight": 0.6, "score": 3, "rationale": "r"},
                    {"criterion_id": "c2", "weight": 0.4, "score": 3, "rationale": "r"},
                ],
                "weighted_score": 0.6,
            },
        ]
    ]
    assert rank_alternatives(analyses)[0] == "a"


def test_derive_scores_is_deterministic_and_evidence_backed(documents):
    criteria = [
        Criterion.model_validate(item)
        for item in [
            {"criterion_id": "dev-speed", "name": "Dev", "weight": 0.5, "description": "d"},
            {"criterion_id": "scalability", "name": "Scale", "weight": 0.5, "description": "d"},
        ]
    ]
    research = {
        "evidence": [
            {
                "document_id": "doc-1",
                "title": "Monolito modular",
                "excerpt": "Un monolito modular organiza módulos.",
            }
        ]
    }

    alternatives = [{"alternative_id": "modular-monolith", "name": "Monolito modular"}]

    first = derive_scores_from_evidence(
        user_request="Equipo pequeño, presión por entregar rápido",
        system_profile={},
        criteria=criteria,
        alternatives=alternatives,
        research_artifact=research,
    )
    second = derive_scores_from_evidence(
        user_request="Equipo pequeño, presión por entregar rápido",
        system_profile={},
        criteria=criteria,
        alternatives=alternatives,
        research_artifact=research,
    )
    assert first == second

    # All cited evidence IDs exist in the research artifact.
    for scores in first.values():
        for score in scores:
            for evidence_id in score["evidence_ids"]:
                assert evidence_id in {item["document_id"] for item in research["evidence"]}


# ---------------------------------------------------------------------------
# 10. Aislamiento de escritura
# ---------------------------------------------------------------------------


def test_specialists_only_update_their_assigned_fields(documents):
    graph = compile_graph(FakeChatModel(), encoder=fake_encoder, documents=documents)
    result = graph.invoke(initial_state())

    # Each artifact exists and routing fields were owned by the supervisor.
    assert result.get("research_artifact") is not None
    assert result.get("analysis_artifact") is not None
    assert result.get("validation_result") is not None
    assert result.get("final_report") is not None
    assert result["routing_reason"]


# ---------------------------------------------------------------------------
# 11. Fallo del modelo: salida segura con estado y motivo explícitos
# ---------------------------------------------------------------------------


def test_model_failure_produces_safe_output(documents):
    graph = compile_graph(BrokenChatModel(), encoder=fake_encoder, documents=documents)
    result = graph.invoke(initial_state())

    assert result["final_report"]["status"] == "limited"
    assert "No se emite recomendación definitiva" in result["final_report"]["recommendation"]
    assert result["routing_reason"]


def test_garbage_response_produces_safe_output(documents):
    graph = compile_graph(GarbageChatModel(), encoder=fake_encoder, documents=documents)
    result = graph.invoke(initial_state())

    assert result["final_report"]["status"] == "limited"


# ---------------------------------------------------------------------------
# 12. Los tests no necesitan clave Groq (fakes en todas las pruebas del grafo)
# ---------------------------------------------------------------------------


def test_graph_tests_use_fakes_only():
    # Sanity check: the fake models used above never call a real API.
    assert not hasattr(FakeChatModel, "invoke_real")
    assert not hasattr(BrokenChatModel, "api_key")
    assert not hasattr(GarbageChatModel, "api_key")
