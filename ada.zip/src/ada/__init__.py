"""Architecture Decision Assistant."""
